import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-cart',
  templateUrl: './update-cart.component.html',
  styleUrls: ['./update-cart.component.css']
})
export class UpdateCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
