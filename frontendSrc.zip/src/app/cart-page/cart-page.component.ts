import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {
  carts:Cart[];
  book:string="JAVA";
  quantity:number=2;
  price:number=100;
  total:number=206;

  constructor(private cartService:CartService) { }

  ngOnInit() {
    this.cartService.getCartPage().subscribe((data:Cart[])=>
    {this.carts=data;console.log("all"+this.carts)});
  
  }
  removeCart(cart:Cart){
    this.cartService.remove(cart).subscribe((data:Cart[])=>
    {this.carts.filter(c=>c!=cart)});
  }

}
