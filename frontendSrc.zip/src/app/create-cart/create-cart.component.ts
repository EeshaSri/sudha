import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { CartService } from '../cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-cart',
  templateUrl: './create-cart.component.html',
  styleUrls: ['./create-cart.component.css']
})
export class CreateCartComponent implements OnInit {
  cartData:Cart={"index": 0,"book":'',"quantity":0,"price":0,"total":0}

  constructor(private cartService:CartService,private router:Router) { }

  ngOnInit() {
  }
  createCart(){
    
    this.cartService.addCart(this.cartData).subscribe((data)=>{this.router.navigate(['cartpage']);});
   alert("added");
  }

}
