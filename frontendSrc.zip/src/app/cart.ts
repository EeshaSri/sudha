export class Cart {
    index:number;
    book:string;
    quantity:number;
    price:number;
    total:number;
    

}
