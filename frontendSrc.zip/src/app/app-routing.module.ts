import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartPageComponent } from './cart-page/cart-page.component';
import { CreateCartComponent } from './create-cart/create-cart.component';


const routes: Routes = [
  {path:'',redirectTo:'cartpage',pathMatch:'full'},
  {path:'cartpage',component:CartPageComponent},
  {path:'create',component:CreateCartComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
