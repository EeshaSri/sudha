import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { Order } from '../bean/order';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-all-orders',
  templateUrl: './get-all-orders.component.html',
  styleUrls: ['./get-all-orders.component.css']
})
export class GetAllOrdersComponent implements OnInit {
orders: Order[];
  constructor(private orderService:OrderService,private route:Router) { }

  ngOnInit() {
    this.orderService.getAllOrders().subscribe((data:Order[])=>
    this.orders=data);
  }

  deleteOrder(order:Order){
    alert: if(window.confirm("Are you sure you want to delete the review with id "+order.orderedId)){
    this.orderService.deleteOrder(order).subscribe((data)=>{this.orders=this.orders.filter(c=>c!==order)});
    }
  }
}
