import { Injectable } from '@angular/core';
import { Order } from './bean/order';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class OrderService {
  url:string="http://localhost:6500/";
  filtereddata:Order[];
  constructor(private http:HttpClient) { }
  addOrder(order:Order){
    return this.http.post(this.url+"cart",order);
  }
  getAllOrders(){
    return this.http.get<Order[]>(this.url+"cart");

  }

  deleteOrder(order:Order){
  console.log(order);
 return this.http.delete<Order[]>(this.url+"cart/"+order.orderedId);
  }
 
 
  editOrder(order:Order){
    return this.http.put(this.url+'cart'+order.orderedId,order);
  }
}
   