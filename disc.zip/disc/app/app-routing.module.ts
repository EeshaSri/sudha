import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetAllOrdersComponent } from './get-all-orders/get-all-orders.component';
import { AddOrderComponent } from './add-order/add-order.component';



const routes: Routes = [
  {path:'',redirectTo:'getAllOrders',pathMatch:'full'},
  {path:'getAllOrders',component:GetAllOrdersComponent},
  {path:'addorder',component:AddOrderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
