package com.cg.book.exception;

public class BookException extends Exception {

	public BookException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BookException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BookException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BookException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BookException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
