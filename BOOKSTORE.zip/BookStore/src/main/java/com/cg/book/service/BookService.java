package com.cg.book.service;

import java.util.List;


import com.cg.book.dto.Book;

import com.cg.book.dto.Category;
import com.cg.book.dto.Customer;
import com.cg.book.dto.DisplayBook;
import com.cg.book.dto.LoginData;
import com.cg.book.dto.Order;
import com.cg.book.dto.Order1;
import com.cg.book.dto.Review;

import com.cg.book.dto.UserManagement;
import com.cg.book.exception.BookException;

public interface BookService {

	List<Category> getAllCategories() throws BookException;

	String addCategory(Category category)throws BookException;

	List<Category> deleteCategory(int id)throws BookException;

	Category getCategory(int id)throws BookException;

	String updateCategory(int id, Category category)throws BookException;

	LoginData validlogin(String email)throws BookException;

	boolean addlogin(LoginData login)throws BookException;

	boolean addBook(DisplayBook book) throws BookException;

	boolean deleteBook(int id) throws BookException;

	List<Book> getBooks() throws BookException;

	DisplayBook getBook(int id) throws BookException;

	List<Book> updateBook(DisplayBook book) throws BookException;
	UserManagement addUser(UserManagement userManagement) throws BookException;

	UserManagement getUserById(int id)throws BookException;

	List<UserManagement> updateUser(int id, UserManagement userManagement) throws BookException;

	List<UserManagement> deleteUser(int id) throws BookException;

	List<UserManagement> getAllUsers() throws BookException;
	List<Review> getAllReviews() throws BookException;
	Review getReviewById(int id) throws BookException;
	List<Review> addReview(Review review) throws BookException;
	List<Review> deleteReview(int Id) throws BookException;
	List<Review> editReview(int Id,Review review)throws BookException;
	List<Customer> getAllCustomers() throws BookException;
    List<Customer> addCustomer(Customer customer) throws BookException;
   Customer getCustomerById(int id) throws BookException;
    List<Customer> deleteCustomer(int id)throws BookException;
	List<Customer> updateCustomer(Customer customer, int id) throws BookException;
	Customer validCustomer(String email) throws BookException;

	List<Book> searchBook(String category) throws BookException;
	
	 List<Order> getAllOrders() throws BookException; 
		boolean addOrder(Order cart) throws BookException;
		
		Order getOrderById(int orderedId) throws BookException;
		List<Order> updateOrder(int orderedId,Order cart) throws BookException;
		List<Order> deleteOrder(int orderedId) throws BookException;
		Book getBookByTitle(String title);

		List<Order> getOrderByName(String fullName)throws BookException;

		boolean addReviews(Review review) throws BookException;

		void deleteBookbyCategory(String categoryName)throws BookException;

	
}
