package com.cg.book.dao;



import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.book.dto.Order;
import com.cg.book.exception.BookException;







@Repository
public interface CartRepository extends JpaRepository<Order,Integer> {
@Query("from Order where name=:fullName")
	List<Order> getOrderbyName(@PathParam("fullName") String fullName)throws BookException;




	
}
