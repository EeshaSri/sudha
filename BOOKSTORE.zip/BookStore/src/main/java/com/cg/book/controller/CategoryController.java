package com.cg.book.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.book.dto.Book;

import com.cg.book.dto.Category;
import com.cg.book.dto.Customer;
import com.cg.book.dto.DisplayBook;
import com.cg.book.dto.LoginData;
import com.cg.book.dto.Order;
import com.cg.book.dto.Order1;
import com.cg.book.dto.Review;

import com.cg.book.dto.UserManagement;
import com.cg.book.exception.BookException;
import com.cg.book.service.BookService;

@CrossOrigin("http://localhost:4200")
@RestController
public class CategoryController {
	@Autowired
	private BookService bookservice;

	@GetMapping("/allCategories")
	public List<Category> getAllCategories() throws BookException {
		return bookservice.getAllCategories();
	}

	@PostMapping("/addCategory")
	public String addCategory(@RequestBody Category category) throws BookException {
		return bookservice.addCategory(category);
	}

	@DeleteMapping("/deleteCategory/{id}")
	public List<Category> deleteCategory(@PathVariable int id) throws BookException {
		return bookservice.deleteCategory(id);
	}

	@GetMapping("/getCategory/{id}")
	public Category getCategory(@PathVariable int id) throws BookException {
		return bookservice.getCategory(id);
	}

	@PutMapping("/updateCategory/{id}")
	public String updateCategory(@PathVariable int id, @RequestBody Category category) throws BookException {
		return bookservice.updateCategory(id, category);
	}

	@ExceptionHandler(BookException.class)
	public ResponseEntity<String> handleException(Exception ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);

	}

	@GetMapping("/login/{email}")
	public LoginData validateLogin(@PathVariable String email) throws BookException {
		return bookservice.validlogin(email);
	}

	@PostMapping("/login")
	public boolean addlogin(@RequestBody LoginData login) throws BookException {
		return bookservice.addlogin(login);
	}

	@PostMapping
	public void addBook(@RequestBody DisplayBook book) throws BookException {
		bookservice.addBook(book);
	}

	@DeleteMapping("/delete/{id}")
	public void deleteBook(@PathVariable int id) throws BookException {
		bookservice.deleteBook(id);
	}

	@GetMapping("/getBooks")
	public List<Book> getBooks() throws BookException {
		return bookservice.getBooks();
	}

	@GetMapping("/getById/{id}")
	public DisplayBook getById(@PathVariable int id) throws BookException {
		return bookservice.getBook(id);
	}

	@PutMapping("/update")
	public List<Book> updateBook(@RequestBody DisplayBook book) throws BookException {

		return bookservice.updateBook(book);
	}

	@GetMapping("/")
	public List<UserManagement> getAllUsers() throws BookException {
		// TODO Auto-generated method stub
		return bookservice.getAllUsers();
	}

	@PostMapping("/add")
	public UserManagement addUser(@RequestBody UserManagement userManagement) throws BookException {
		return bookservice.addUser(userManagement);
	}

	@PutMapping("/edit/{id}")
	public List<UserManagement> updateUser(@PathVariable int id, @RequestBody UserManagement userManagement)
			throws BookException {
		System.out.println(id);
		return bookservice.updateUser(id, userManagement);
	}

	@GetMapping("/users/{id}")
	public UserManagement getUserById(@PathVariable int id) throws BookException {
		return bookservice.getUserById(id);
	}

	@DeleteMapping("/deletes/{id}")
	public List<UserManagement> deleteUser(@PathVariable int id) throws BookException {
		return bookservice.deleteUser(id);

	}

	@GetMapping("/reviews")
	public List<Review> getAllReviews() throws BookException {
		return bookservice.getAllReviews();
	}

	@GetMapping("/reviews/{Id}")
	public Review getReviewById(@PathVariable int Id) throws BookException {
		return bookservice.getReviewById(Id);
	}

	@PostMapping("/reviews")
	public List<Review> addReview(@RequestBody Review review) throws BookException {
		return bookservice.addReview(review);
	}

	@DeleteMapping("/reviews/{Id}")
	public List<Review> deleteReview(@PathVariable int Id) throws BookException {
		System.out.println(Id);
		return bookservice.deleteReview(Id);

	}

	@PutMapping("/reviews/{Id}")
	public List<Review> editReview(@RequestBody Review review, @PathVariable int Id) throws BookException {
		return bookservice.editReview(Id, review);
	}

	@PostMapping("/addReview")
	public List<Review> addUser(@RequestBody Review Reviwes) throws BookException {
		return bookservice.addReview(Reviwes);
	}

	@GetMapping("/customer")
	public List<Customer> getAllCustomers() throws BookException {
		return bookservice.getAllCustomers();
	}

	@PostMapping("/customer")

	public List<Customer> addCustomer(@RequestBody Customer customer) throws BookException {
		return bookservice.addCustomer(customer);
	}

	@DeleteMapping("/customer/{id}")
	public List<Customer> deleteCustomer(@PathVariable int id) throws BookException {
		return bookservice.deleteCustomer(id);
	}

	@PutMapping("/customer/{id}")
	public List<Customer> updateCustomer(@RequestBody Customer customer, @PathVariable int id) throws BookException {
		return bookservice.updateCustomer(customer, id);
	}

	@GetMapping("/customer/{id}")
	public Customer getCustomerById(@PathVariable int id) throws BookException {
		return bookservice.getCustomerById(id);
	}

	@GetMapping("/customerlogin/{email}")
	public Customer getCustomer(@PathVariable String email) throws BookException {
		return bookservice.validCustomer(email);
	}

	@GetMapping("/searchbook/{category}")
	public List<Book> searchBook(@PathVariable String category) throws BookException {
		return bookservice.searchBook(category);
	}

	@GetMapping("/carts")
	public List<Order> getAllOrders() throws BookException {
		return bookservice.getAllOrders();
	}

	@PostMapping("/addCart")
	public void addOrder(@RequestBody Order order) throws BookException {
		bookservice.addOrder(order);
	}

	@DeleteMapping("/cart/{orderedId}")
	List<Order> deleteCourse(@PathVariable int orderedId) throws BookException {
		return bookservice.deleteOrder(orderedId);
	}

	@PutMapping("/cart/{orderedId}")
	List<Order> updateCourse(@RequestBody Order order, @PathVariable int orderedId) throws BookException {
		return bookservice.updateOrder(orderedId, order);
	}

	@GetMapping("/cartbyName/{fullName}")
	public List<Order> getOrderById(@PathVariable String fullName) throws BookException {
		return bookservice.getOrderByName(fullName);
	}

	@GetMapping("/getBookByTitle/{title}")
	public Book getBookByTitle(@PathVariable String title) {
		return bookservice.getBookByTitle(title);
	}
	
	@PostMapping("/addreview")
	public void addReviews(@RequestBody Review review) throws BookException
	{
		bookservice.addReviews(review);
	}
	@DeleteMapping("/deletebookbycateg/{categoryName}")
	public void deleteBookbycategory(@PathVariable String categoryName) throws BookException {
		System.out.println("hiii");
		bookservice.deleteBookbyCategory(categoryName);
	}
	@GetMapping("/cart/{orderedId}")
	public Order getOrderById(@PathVariable int orderedId) throws BookException
	{
		return bookservice.getOrderById(orderedId);
	}
	
}
