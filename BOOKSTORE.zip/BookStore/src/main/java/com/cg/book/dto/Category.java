package com.cg.book.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name = "categories")
public class Category {
	@Id
	@SequenceGenerator(name = "Id6", sequenceName = "Id6",initialValue = 10,allocationSize = 4)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "Id6")
	private int id;
	private String CategoryName;
	
	
	
	
	
	public String getCategoryName() {
		return CategoryName;
	}
	public void setCategoryName(String categoryName) {
		CategoryName = categoryName;
	}
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(int id, String categoryName, int ind) {
		super();
		this.id = id;
		CategoryName = categoryName;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
	
	
}
