package com.cg.book.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.book.dto.DisplayBook;



public interface DisplayBookDao extends JpaRepository<DisplayBook, Integer> {

}
