package com.cg.book.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.book.dto.LoginData;
@Repository
public interface LoginDataDao extends JpaRepository<LoginData,String> {

}
