package com.cg.book.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.book.dto.Book;


@Repository
public interface BookDao extends JpaRepository<Book, Integer>{

	@Query("from Book where title=:title")
	public Book getBookByTitle(String title);
}
