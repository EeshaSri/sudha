package com.cg.book.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.book.dao.BookDao;
import com.cg.book.dao.CartRepository;
import com.cg.book.dao.CategoryDao;
import com.cg.book.dao.CustomerRepository;
import com.cg.book.dao.DisplayBookDao;
import com.cg.book.dao.LoginDataDao;
import com.cg.book.dao.ReviewRepository;

import com.cg.book.dao.UserDao;
import com.cg.book.dto.Book;

import com.cg.book.dto.Category;
import com.cg.book.dto.Customer;
import com.cg.book.dto.DisplayBook;
import com.cg.book.dto.LoginData;
import com.cg.book.dto.Order;
import com.cg.book.dto.Order1;
import com.cg.book.dto.Review;

import com.cg.book.dto.UserManagement;
import com.cg.book.exception.BookException;

@Service
public class bookServiceImpl implements BookService {
	@Autowired
	private CategoryDao dao;
	@Autowired
	private BookDao bookdao;
	@Autowired
	private DisplayBookDao dao1;
	@Autowired
	private LoginDataDao logindao;
	@Autowired
	private ReviewRepository reviewDao;
	@Autowired
	private CustomerRepository custdao;
	@Autowired
	private CartRepository cartdao;
	
	

	@Autowired
	UserDao userDao;

	@Override
	public List<Category> getAllCategories() throws BookException {
		return dao.getAllCategories();
	}

	@Override
	public String addCategory(Category category) throws BookException {

		dao.save(category);

		return "added successfully";
	}

	@Override
	public List<Category> deleteCategory(int id) throws BookException {
		// TODO Auto-generated method stub
		dao.deleteById(id);
		return dao.getAllCategories();
	}

	@Override
	public Category getCategory(int id) throws BookException {
		Category cg = dao.findById(id).get();
		System.out.println(cg.getCategoryName());
		return cg;
	}

	@Override
	public String updateCategory(int id, Category category) throws BookException {
		if (dao.existsById(id)) {
			Category cat = dao.findById(id).get();
			String name = category.getCategoryName();
			System.out.println(name);
			cat.setCategoryName(name);
			dao.save(cat);
		}
		return "updated Successfully";
	}

	@Override
	public LoginData validlogin(String email) throws BookException {
		boolean status = false;

		if (logindao.existsById(email)) {

			status = true;

		}

		return logindao.findById(email).get();
	}

	@Override
	public boolean addlogin(LoginData login) throws BookException {
		// TODO Auto-generated method stub
		logindao.save(login);
		return true;
	}

	@Override
	public boolean addBook(DisplayBook book) throws BookException {
		Book b = new Book();
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		b.setAuthor(book.getAuthor());
		b.setCategory(book.getCategory());
		b.setDescription(book.getDescription());
		b.setPrice(book.getPrice());
		b.setTitle(book.getTitle());
		b.setIsbn(book.getIsbn());
		Date d = new Date();
		String dt = formatter.format(d);
		try {
			d = formatter.parse(dt);
		} catch (ParseException e) {

			System.out.println(e.getMessage());

		}
		dao1.save(book);
		b.setId(book.getId());
		b.setPublishedDate(d);

		bookdao.save(b);
		return true;
	}

	@Override
	public boolean deleteBook(int id) throws BookException {
		int mainId = 0;
		List<Book> books = bookdao.findAll();
		for (Book book2 : books) {
			if (book2.getId() == id) {
				bookdao.deleteById(id);
			}
		}
		
		return true;
	}

	@Override
	public List<Book> getBooks() throws BookException {
		return bookdao.findAll();
	}

	@Override
	public DisplayBook getBook(int id) throws BookException {
		System.out.println(dao1.findById(id).get());
		return dao1.findById(id).get();
	}

	@Override
	public List<Book> updateBook(DisplayBook book) throws BookException {
		int mainId = 0;

		List<Book> books = bookdao.findAll();
		for (Book book2 : books) {
			if (book2.getId() == book.getId()) {
				mainId = book2.getId();
			}
		}
		Book b = bookdao.findById(mainId).get();
		b.setAuthor(book.getAuthor());
		b.setCategory(book.getCategory());
		b.setDescription(book.getDescription());
		b.setPrice(book.getPrice());
		b.setTitle(book.getTitle());
		b.setIsbn(book.getIsbn());
		bookdao.save(b);
		return getBooks();
	}

	@Override
	public UserManagement addUser(UserManagement userManagement) throws BookException {
		
		if(logindao.existsById(userManagement.getEmail())) {
		return null;
		}
		else {
			LoginData login = new LoginData(userManagement.getEmail(), userManagement.getPassword());
			logindao.save(login);
			return userDao.save(userManagement);
		}
	}

	@Override
	public UserManagement getUserById(int id) throws BookException {
		try {

			Optional<UserManagement> data = userDao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new BookException("User with Id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<UserManagement> updateUser(int id, UserManagement userManagement) throws BookException {
		if (userDao.existsById(userManagement.getId())) {
			userDao.save(userManagement);
			return getAllUsers();
		} else {
			throw new BookException("Invalid User, cannot be  updated");
		}
	}

	@Override
	public List<UserManagement> deleteUser(int id) throws BookException {
		if (userDao.existsById(id)) {

			userDao.deleteById(id);
			return getAllUsers();
		} else {
			throw new BookException("cannot delete. User with Id " + id + " does not exist");
		}
	}

	@Override
	public List<UserManagement> getAllUsers() throws BookException {
		try {
			return userDao.findAll();
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Review> getAllReviews() throws BookException {
		return reviewDao.findAll();
	}

	@Override
	public Review getReviewById(int id) throws BookException {
		try {
			Optional<Review> data = reviewDao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new BookException("Review with id " + id + " does not exist");
			}
		} catch (Exception e) {
			throw new BookException(e.getMessage());

		}

	}

	@Override
	public List<Review> addReview(Review review) throws BookException {
		reviewDao.save(review);
		return getAllReviews();
	}

	@Override
	public List<Review> deleteReview(int Id) throws BookException {
		reviewDao.deleteById(Id);
		return getAllReviews();
	}

	@Override
	public List<Review> editReview(int Id, Review review) throws BookException {
		try {
			if (reviewDao.existsById(Id)) {
				Review review1 = reviewDao.findById(Id).get();
				review1.setHeadline(review.getHeadline());
				reviewDao.save(review1);
				return getAllReviews();
			} else {
				throw new BookException("Id doesnt exist");
			}
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Customer> getAllCustomers() throws BookException {
		try {
			return custdao.findAll();
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Customer> addCustomer(Customer customer) throws BookException {
		try {
			custdao.save(customer);

			long millis = System.currentTimeMillis();
			java.sql.Date date = new java.sql.Date(millis);

			customer.setRegisteredDate(date);
			System.out.println(customer);
			custdao.save(customer);
			// return getcustomer();

			return getAllCustomers();

		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public Customer getCustomerById(int id) throws BookException {
		try {
			Optional<Customer> data = custdao.findById(id);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new BookException("customer with Id " + id + "does not match");
			}
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Customer> deleteCustomer(int id) throws BookException {
		if (custdao.existsById(id)) {
			custdao.deleteById(id);
			return getAllCustomers();
		} else {
			throw new BookException("cannot delete.Customer with Id" + id + "does not exist");
		}
	}

	@Override
	public List<Customer> updateCustomer(Customer customer, int id) throws BookException {
		if (custdao.existsById(id)) {
			// custdao.delete(customer);
			custdao.save(customer);
			return getAllCustomers();
		} else {
			throw new BookException("Invalid Customer,cannot be updated");
		}
	}

	@Override
	public Customer validCustomer(String email) throws BookException {
		boolean status = false;
		Customer cust = new Customer();
		List<Customer> list = custdao.findAll();
		for (Customer customer : list) {
			String email1 = customer.getEmail();
			System.out.println(email1);
			System.out.println(email);
			if (email.equals(email1)) {
				cust = customer;
				status = true;
			}
		}
		if (status) {
			return cust;
		} else {
			return null;
		}

	}

	@Override
	public List<Book> searchBook(String category) throws BookException {
		// TODO Auto-generated method stub
		List<Book> list = bookdao.findAll();
		List<Book> list1 = new ArrayList<>();
		for (Book book : list) {
			String cat = book.getCategory();
			if (cat.equalsIgnoreCase(category)) {
				list1.add(book);
			}

		}
		return list1;
	}

	@Override
	public List<Order> getAllOrders() throws BookException {

		try {
			return cartdao.findAll();
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public boolean addOrder(Order cart) throws BookException {
		long millis = System.currentTimeMillis();
		java.sql.Date date = new java.sql.Date(millis);
		System.out.println(date);
		cart.setOrdereddate(date);
		cartdao.save(cart);
		return true;
	}

	@Override
	public Order getOrderById(int orderedId) throws BookException {
		try {
			Optional<Order> data = cartdao.findById(orderedId);
			if (data.isPresent()) {
				return data.get();
			} else {
				throw new BookException("cart doesnt exist");
			}
		} catch (Exception e) {
			throw new BookException(e.getMessage());
		}
	}

	@Override
	public List<Order> updateOrder(int orderedId, Order cart) throws BookException {
		if (cartdao.existsById(orderedId)) {
			cartdao.save(cart);
			return getAllOrders();

		} else {
			throw new BookException("cant update");
		}
	}

	@Override
	public List<Order> deleteOrder(int orderedId) throws BookException {
		if (cartdao.existsById(orderedId)) {
			cartdao.deleteById(orderedId);
			return getAllOrders();
		} else {
			throw new BookException("cannot delete");
		}
	}

	@Override
	public Book getBookByTitle(String title) {
		return bookdao.getBookByTitle(title);
	}

	@Override
	public List<Order> getOrderByName(String fullName) throws BookException {
		// TODO Auto-generated method stub
		return cartdao.getOrderbyName(fullName);
	}

	@Override
	public boolean addReviews(Review review) throws BookException {

		reviewDao.save(review);
		return true;
	}

	@Override
	public void deleteBookbyCategory(String categoryName) throws BookException {
		List<Book> list = bookdao.findAll();
		Iterator<Book> iterator = list.iterator();
		while (iterator.hasNext()) {
			Book book = iterator.next();
			if (book.getCategory().equalsIgnoreCase(categoryName)) {
				bookdao.deleteById(book.getId());
				System.out.println("deleteeee");
			}
		}

	}

	

}
