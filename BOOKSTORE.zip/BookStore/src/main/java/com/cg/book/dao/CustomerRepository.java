package com.cg.book.dao;

import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.book.dto.Customer;




@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer>{

	

}
