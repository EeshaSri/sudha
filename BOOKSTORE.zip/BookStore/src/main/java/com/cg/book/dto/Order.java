package com.cg.book.dto;






import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="OrderDetail")
public class Order {
	@Id
	@SequenceGenerator(name="seq",sequenceName = "seq", initialValue=1000, allocationSize=1)
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq")
	private int orderedId;
	private String name;
	private int quantity;
	private int amount;
	@Column(name="met")
	private String method;
	@Column(name="stat")
	private String status;
	
	private Date ordereddate ;
	public int getOrderedId() {
		return orderedId;
	}
	public void setOrderedId(int orderedId) {
		this.orderedId = orderedId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getOrdereddate() {
		return ordereddate;
	}
	public void setOrdereddate(Date ordereddate) {
		this.ordereddate = ordereddate;
	}
	
}
