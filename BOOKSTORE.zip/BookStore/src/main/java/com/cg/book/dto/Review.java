package com.cg.book.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Index;
import org.springframework.web.bind.annotation.CrossOrigin;

@Entity


public class Review {
	
	/*
	 * @SequenceGenerator(name = "mysq", sequenceName = "reviewsq",initialValue = 1,
	 * allocationSize = 1)
	 * 
	 * @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mysq")
	 * 
	 * @Column(name="ind") private int index;
	 */
	@Id
	@SequenceGenerator(name = "ID_Generator", sequenceName = "reviewseq",initialValue = 1000, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ID_Generator")
	@Column(name="idv")
	private int id;
	private String book;
	private int rating;
	private String headline;
	private String customer;
	private String reviewOn;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBook() {
		return book;
	}
	public void setBook(String book) {
		this.book = book;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getReviewOn() {
		return reviewOn;
	}
	public void setReviewOn(String reviewOn) {
		this.reviewOn = reviewOn;
	}
	
	
	
}
