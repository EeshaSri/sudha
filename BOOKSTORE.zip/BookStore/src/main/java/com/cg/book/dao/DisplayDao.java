package com.cg.book.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.book.dto.DisplayBook;



public interface DisplayDao  extends JpaRepository<DisplayBook, Integer>{

}
