import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../service/customer.service';
import { Customer } from '../model/customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  customers:Customer[];
  //searchItem:string='';
  searchItem:number=0;
  searchData:Customer[];

  constructor( private service:CustomerService) { }

  ngOnInit() {
    this.service.getAllCustomers().subscribe((data:Customer[])=>{this.customers=data;console.log("all"+this.customers)});
  }
//
//search(value:string){
  search(value:number){
//this.searchData=this.customers.filter(customer=>customer.name.toLowerCase().indexOf(value.toLowerCase())!==-1);
this.searchData=this.customers.filter(customer=>customer.id==value);
this.service.setSearcheddata(this.searchData);
//this.router.navigate(['showsearcheddata']);

}

}

