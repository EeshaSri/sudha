import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CartPageComponent } from './cart-page/cart-page.component';
import { CreateCartComponent } from './create-cart/create-cart.component';
import { RemoveCartComponent } from './remove-cart/remove-cart.component';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { CartService } from './cart.service';
import{ FormsModule,ReactiveFormsModule} from '@angular/forms';
import{ HttpClientModule} from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    CartPageComponent,
    CreateCartComponent,
    RemoveCartComponent,
    UpdateCartComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [CartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
