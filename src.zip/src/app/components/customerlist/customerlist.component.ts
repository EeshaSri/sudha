import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/service/customer.service';
import { Customer } from 'src/app/model/customer';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.css']
})
export class CustomerlistComponent implements OnInit {
customers:Customer[];
name:string="sudhapadmasree";
dob=new Date(1996,1,17);
salary=12435.234;
  constructor(private customerService:CustomerService) { }

  ngOnInit() {
    this.customerService.getAllCustomers().subscribe((data:Customer[])=>
    {this.customers=data;console.log("all"+this.customers)});
  
  }
  deleteCustomer(customer:Customer){
    this.customerService.deleteCustomer(customer).subscribe((data:Customer[])=>
    {this.customers.filter(c=>c!==customer)});
  }

}
