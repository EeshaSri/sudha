import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remove-cart',
  templateUrl: './remove-cart.component.html',
  styleUrls: ['./remove-cart.component.css']
})
export class RemoveCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
