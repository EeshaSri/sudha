import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Cart } from './cart';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  url:string="http://locathost:4200/cart";
  filtereddata:Cart[];

  constructor(private http:HttpClient) { }
addCart(cart:Cart){
  return this.http.post(this.url,cart);
}
getCartPage(){
  return this.http.get<Cart[]>(this.url);
}
remove(cart:Cart){
  return this.http.delete<Cart[]>(this.url+"/"+cart.book);
}
update(cart:Cart){
  return this.http.put(this.url+"/"+cart.index,cart);
}
}
