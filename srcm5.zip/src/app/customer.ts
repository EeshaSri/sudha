export class Customer {
  accountNumber: number;
  title:string;
  email:string;
  phone:number;
  amount:number;

  constructor( title:string, email:string, phone:number, amount:number) {
   this.title = title;
   this.email = email;
   this.phone = phone;
   this.amount = amount;
  }

}