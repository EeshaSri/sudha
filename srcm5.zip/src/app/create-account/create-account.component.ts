
import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {

  customer: Customer;
  constructor(private customerService: CustomerService) {

  }

  createCustomer(title: string, email: string, phone: number, amount: number): void {
    if (title && email && phone && amount) {
      this.customer = new Customer(title, email, phone, amount);
      this.customerService.createCustomer(this.customer)
        .subscribe((data) => {
          alert('Account Created Successfully!');
          console.log(this.customer.accountNumber);
        });
    } else {
      alert('Please fill all details');
    }

  }
}
