import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { ShowCategoryComponent } from './component/show-category/show-category.component';
import { CreateCategoryComponent } from './component/create-category/create-category.component';
import { EditCategoryComponent } from './component/edit-category/edit-category.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Category } from './bean/category';
import { CategoryService } from './service/category.service';
import { LoginComponent } from './component/login/login.component';
import { BookListComponent } from './component/book-list/book-list.component';
import { ShowBookComponent } from './component/show-book/show-book.component';
import { UpdateComponent } from './component/update/update.component';
import { UserlistComponent } from './component/user-list/userlist.component';
import { CreateuserComponent } from './component/create-user/createuser.component';
import { EdituserComponent } from './component/edit-user/edituser.component';
import { EditComponent } from './component/edit/edit.component';
import { ReviewlistingpageComponent } from './component/reviewlistingpage/reviewlistingpage.component';
import { AddcustomerComponent } from './component/addcustomer/addcustomer.component';
import { ShowlistComponent } from './component/showCustomer/showlist.component';
import { EditcustomerComponent } from './component/editcustomer/editcustomer.component';
import { CustomerHomePageComponent } from './component/customer-home-page/customer-home-page.component';
import { LoginCustomerComponent } from './component/login-customer/login-customer.component';
import { RegisterCustomerComponent } from './component/register-customer/register-customer.component';
import { ShowCustomerComponent } from './component/show-customer/show-customer.component';
import { EditcustomerloginComponent } from './component/editcustomerlogin/editcustomerlogin.component';
import { CustomerHomePageRegisterComponent } from './component/customer-home-page-register/customer-home-page-register.component';
import { ShoppingCartComponent } from './component/shopping-cart/shopping-cart.component';
import { CheckOutPageComponent } from './component/check-out-page/check-out-page.component';
import { GetAllOrdersComponent } from './component/get-all-orders/get-all-orders.component';
import { AddOrderComponent } from './component/add-order/add-order.component';
import { MyOrdersComponent } from './component/my-orders/my-orders.component';
import { ViewOrderComponent } from './component/view-order/view-order.component';
import { WriteReviewComponent } from './component/write-review/write-review.component';
import { MainPageComponent } from './component/main-page/main-page.component';
import { EditOrderComponent } from './component/edit-order/edit-order.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    ShowCategoryComponent,
    CreateCategoryComponent,
    EditCategoryComponent,
    LoginComponent,
    BookListComponent,
    ShowBookComponent,
    UpdateComponent,
    UserlistComponent,
    CreateuserComponent,
    EdituserComponent,
    EditComponent,
    ReviewlistingpageComponent,
    AddcustomerComponent,
    ShowlistComponent,
    EditcustomerComponent,
    CustomerHomePageComponent,
    LoginCustomerComponent,
    RegisterCustomerComponent,
    ShowCustomerComponent,
    EditcustomerloginComponent,
    CustomerHomePageRegisterComponent,
    ShoppingCartComponent,
    CheckOutPageComponent,
    GetAllOrdersComponent,
    AddOrderComponent,
    MyOrdersComponent,
    ViewOrderComponent,
    WriteReviewComponent,
    MainPageComponent,
    EditOrderComponent
  ],
  imports: [
    
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CategoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
