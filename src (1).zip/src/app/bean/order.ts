export class Order {
    orderedId:number;
    name:string;
    quantity:number;
    amount:number;
    method:string;
    status:string;
    ordereddate:Date;
}
