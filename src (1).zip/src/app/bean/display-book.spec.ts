import { DisplayBook } from './display-book';

describe('DisplayBook', () => {
  it('should create an instance', () => {
    expect(new DisplayBook()).toBeTruthy();
  });
});
