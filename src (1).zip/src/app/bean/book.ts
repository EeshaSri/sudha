export class Book {
    id:number;
    index:number;
    category:string;
    title:string;
    author:string;
    publishedDate:Date;
    isbn:string;
    price:number;
    image:string;
}
