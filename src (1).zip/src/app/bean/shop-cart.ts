export class ShopCart {
    
    price:number;
    image:string;
    title:string;
    quantity:number;
    subtotal:number;
}
