export class Order1 {
    name:string;
    quantity:number;
    amount:number;
    method:string;
    status:string;
    date:Date;
}
