export class User {
    id:number;
    email:string;
    fullname:string;
    password:string;
   }