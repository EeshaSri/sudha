import { ShopCart } from './shop-cart';

describe('ShopCart', () => {
  it('should create an instance', () => {
    expect(new ShopCart()).toBeTruthy();
  });
});
