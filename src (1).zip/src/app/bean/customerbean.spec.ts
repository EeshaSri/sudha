import { Customerbean } from './customerbean';

describe('Customerbean', () => {
  it('should create an instance', () => {
    expect(new Customerbean()).toBeTruthy();
  });
});
