export class DisplayBook {
    category:string;
    title:string;
    author:string;
    description:string;
    isbn:string;
    price:number;
    image:string;

}
