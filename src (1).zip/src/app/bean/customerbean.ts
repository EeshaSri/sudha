export class Customerbean {
    id:number;
    email:string;
    fullName:string;
    phoneNumber:string;
    password:string;
    address:string;
    city:string;
    state:string;
    country:string;
    registeredDate:Date;



}
