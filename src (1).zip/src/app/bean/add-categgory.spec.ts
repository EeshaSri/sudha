import { AddCateggory } from './add-categgory';

describe('AddCateggory', () => {
  it('should create an instance', () => {
    expect(new AddCateggory()).toBeTruthy();
  });
});
