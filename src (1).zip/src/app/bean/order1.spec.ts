import { Order1 } from './order1';

describe('Order1', () => {
  it('should create an instance', () => {
    expect(new Order1()).toBeTruthy();
  });
});
