export class AddCategory {
    categoryName:string;

    constructor(categoryName:string){
        this.categoryName=categoryName;
    }
}
