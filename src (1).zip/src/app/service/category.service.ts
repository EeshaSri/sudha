import { Injectable } from '@angular/core';
import { Category } from '../bean/category';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AddCateggory } from '../bean/add-categgory';
import { AddCategory } from '../bean/add-category';
import { LoginData } from '../bean/login-data';
import { DisplayBook } from '../bean/display-book';
import { Book } from '../bean/book';
import { User } from '../bean/user.interface';
import { Review } from '../bean/review';
import { Customerbean } from '../bean/customerbean';
import { Order } from '../bean/order';
import { ShopCart } from '../bean/shop-cart';
import { Order1 } from '../bean/order1';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categories:Category[];
  customerObj:Customerbean;
  filteredbooks:Book[];
  reviewBook:Book;
  ct:ShopCart[]=[];
  cart:ShopCart;
  order:Order;
  checkOutCart:ShopCart[];
  registerCustomer:Customerbean;
  loginCustomer:Customerbean;
  PlacedOrder:Order;
  private userUrl = 'http://localhost:4000';
  constructor(private http: HttpClient) { }

public getAllCategories():Observable<Category[]>{
return this.http.get<Category[]>(this.userUrl+'/allCategories');
  }

  public addCategory(category: Category): Observable<AddCategory> {
    return this.http.post<AddCategory>(this.userUrl + '/addCategory', category);
  }
  deleteCustomer(categ:Category){
    return this.http.delete<Category[]>(this.userUrl+"/deleteCategory/"+categ.id);
  }
  getCategory(id:number):Observable<Category>{
    return this.http.get<Category>(this.userUrl+"/getCategory/"+id);
  }
  updateCategory(categ:Category){
    return this.http.put(this.userUrl+"/updateCategory/"+categ.id,categ);
  }
  validlogin(login:LoginData):Observable<LoginData>{
    return this.http.get<LoginData>(this.userUrl+'/login/'+login.email);
  }
  add(book:DisplayBook)
  {
return this.http.post(this.userUrl,book);
  }
  getBooks():Observable<Book[]>
  {
    return this.http.get<Book[]>(this.userUrl+'/getBooks');
  }
  getById( id:number):Observable<DisplayBook>
  {
    return this.http.get<DisplayBook>(this.userUrl+'/getById/'+id);
  }
  update(book:DisplayBook)
  {
return this.http.put<DisplayBook>(this.userUrl+'/update',book);
  }
  delete(id:number)
  {
    return this.http.delete(this.userUrl+'/delete/'+id)
  }
  getAllUsers() {
    return this.http.get<User[]>(this.userUrl);
  }
  createUser(user: User): Observable<User> {
    return this.http.post<User>(this.userUrl + "/add", user);
  }
  deleteUser(user: User) {
    return this.http.delete<User[]>(this.userUrl + "/deletes/" + user.id);
  }
  editUser(user: User) {
    return this.http.put(this.userUrl + "/edit/" + user.id, user);
  }
  getUser(id: number) {
    return this.http.get<User>(this.userUrl + "/users/" + id);
  }
   getAllReviews(){
    return this.http.get<Review[]>(this.userUrl+'/reviews');
  }
  
  getReview(id:number){
    return this.http.get<Review>(this.userUrl+"/reviews/"+id);
  }
  editReview(review:Review){
    return this.http.put<Review>(this.userUrl+"/reviews/"+review.id,review);
  }
  getOrder(orderedId:number){
    return this.http.get<Order>(this.userUrl+'/cart/'+orderedId)
  }
  deleteReview(review:Review){
    console.log(review);
    return this.http.delete<Review[]>(this.userUrl+"/reviews/"+review.id);
  }
  addCustomer(customer:Customerbean){
    this.registerCustomer=customer;
    return this.http.post(this.userUrl+"/customer",customer);
  }
  getAllCustomers(){
   return this.http.get<Customerbean[]>(this.userUrl+"/customer/");
  }
  deleteCustomers(id:number){
 return this.http.delete<Customerbean[]>(this.userUrl+"/customer/"+id);
  }
  getCustomer(id:number){
    return this.http.get<Customerbean>(this.userUrl+"/customer/"+id);
     }
     editcustomer(customer:Customerbean){
      // this.loginCustomer=customer;
       return this.http.put(this.userUrl+"/customer/"+customer.id,customer);
     }
     validCustomer(login:LoginData):Observable<Customerbean>{
      return this.http.get<Customerbean>(this.userUrl+'/customerlogin/'+login.email);
    }

    loginData(customer:Customerbean){
this.customerObj=customer;
    }
    showCustomer(){
      return this.customerObj;
    }
    searchBook(category:string)
  {
return this.http.get<Book[]>(this.userUrl+'/searchbook/'+category);
    }

   addOrder(order:Order)
   {
     console.log(order)
return this.http.post(this.userUrl+"/addCart",order);
   }
    getAllOrders(){
      return this.http.get<Order[]>(this.userUrl+"/carts");
  
    }
    
  
    deleteOrder(orderedId:number){
  console.log(orderedId);
   return this.http.delete<Order[]>(this.userUrl+"/cart/"+orderedId);
    }
   
   
    editOrder(order:Order){
      return this.http.put(this.userUrl+'/cart'+order.orderedId,order);
    }
    getOrderbyName(fullName:string):Observable<Order[]>{
      return this.http.get<Order[]>(this.userUrl+'/cartbyName/'+fullName)
    }
    
  editCustomer(order:Order){

    return this.http.put(this.userUrl+'/cart/'+order.orderedId,order);
  }
  remove(title:string){
    return this.http.delete<Book[]>(this.userUrl+"/cart/book/{title}"+title);
  }

  setBookData(book:Book){
this.filteredbooks.push(book);
console.log(this.filteredbooks);
  }
  getBookData(){
    console.log(this.filteredbooks);
    return this.filteredbooks;
    
  }
  addCart(c:ShopCart)
  {
    this.cart=c;
this.ct.push(c);
  }
  getCart()
  
  {
    return this.ct;
  }
  getSinglecart(){
    return this.cart;
  }
  getBookByTitle(title:string){
    return this.http.get<Book>(this.userUrl+"/getBookByTitle/"+title);
  }
  checkOut(order:Order,cart:ShopCart[]){
this.order=order;
this.checkOutCart=cart;
  }

  getCheckOutOrder(){
    return this.order;
  }
   getCheckOutCart(){
     return this.checkOutCart;
   }
   getRegisterCustomer()
   {
     return this.registerCustomer;
   }

   getLoginCustomer(){
     return this.customerObj;
   }
   setOrder(order:Order){
this.PlacedOrder=order;
   }
   getPlacedOrder(){
     return this.PlacedOrder;
   }
   setReview(b:Book)
   {
     console.log(b);
this.reviewBook=b;
   }
   getBookForReview()
   {
    console.log(this.reviewBook);
     return this.reviewBook;
   }
   addReview(review:Review)
   {
     console.log(review);
return this.http.post(this.userUrl+'/addreview/',review);
   }
   deleteBookBycategory(categoryName:String)
   {
     return this.http.delete<Book[]>(this.userUrl+'/deletebookbycateg/'+categoryName);
   }
}
