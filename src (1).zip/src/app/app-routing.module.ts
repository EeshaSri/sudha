import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { ShowCategoryComponent } from './component/show-category/show-category.component';

import { CreateCategoryComponent } from './component/create-category/create-category.component';
import { EditCategoryComponent } from './component/edit-category/edit-category.component';
import { LoginComponent } from './component/login/login.component';
import { BookListComponent } from './component/book-list/book-list.component';
import { ShowBookComponent } from './component/show-book/show-book.component';
import { UpdateComponent } from './component/update/update.component';
import { UserlistComponent } from './component/user-list/userlist.component';
import { CreateuserComponent } from './component/create-user/createuser.component';
import { EdituserComponent } from './component/edit-user/edituser.component';
import { EditComponent } from './component/edit/edit.component';
import { ReviewlistingpageComponent } from './component/reviewlistingpage/reviewlistingpage.component';
import { AddcustomerComponent } from './component/addcustomer/addcustomer.component';
import { ShowlistComponent } from './component/showCustomer/showlist.component';
import { EditcustomerComponent } from './component/editcustomer/editcustomer.component';
import { CustomerHomePageComponent } from './component/customer-home-page/customer-home-page.component';
import { LoginCustomerComponent } from './component/login-customer/login-customer.component';
import { RegisterCustomerComponent } from './component/register-customer/register-customer.component';
import { ShowCustomerComponent } from './component/show-customer/show-customer.component';
import { EditcustomerloginComponent } from './component/editcustomerlogin/editcustomerlogin.component';
import { CustomerHomePageRegisterComponent } from './component/customer-home-page-register/customer-home-page-register.component';
import { ShoppingCartComponent } from './component/shopping-cart/shopping-cart.component';
import { CheckOutPageComponent } from './component/check-out-page/check-out-page.component';
import { AddOrderComponent } from './component/add-order/add-order.component';
import { GetAllOrdersComponent } from './component/get-all-orders/get-all-orders.component';
import { MyOrdersComponent } from './component/my-orders/my-orders.component';
import { ViewOrderComponent } from './component/view-order/view-order.component';
import { WriteReviewComponent } from './component/write-review/write-review.component';
import { MainPageComponent } from './component/main-page/main-page.component';
import { EditOrderComponent } from './component/edit-order/edit-order.component';


const routes: Routes = [

  {path:'',component:MainPageComponent},
  { path: 'login', component: LoginComponent },
  { path: 'welcome', component: WelcomeComponent },
  { path: 'welcome/category', component: ShowCategoryComponent },
  { path: 'welcome/category/create', component: CreateCategoryComponent },
  { path: 'welcome/category/edit/:id', component: EditCategoryComponent },
  { path: 'addbook', component: BookListComponent },
  { path: 'welcome/booklist', component: ShowBookComponent },
  { path: 'welcome/booklist/update/:id', component: UpdateComponent },
  { path: 'welcome/userList', component: UserlistComponent },
  { path: 'welcome/userList/create', component: CreateuserComponent },
  { path: 'welcome/userList/edit/:id', component: EdituserComponent },
  { path: 'welcome/review/edit/:id', component: EditComponent },
  { path: 'welcome/review', component: ReviewlistingpageComponent },
  { path: 'addorder', component: AddOrderComponent },
  { path: 'welcome/getAllOrders', component: GetAllOrdersComponent },
  {path:'welcome/getAllOrders/edit/:orderedId',component:EditOrderComponent},
  { path: 'customerpage/loginCustomer/showcustomer/registerHomePage/myOrders', component: MyOrdersComponent },
  { path: 'addcustomer', component: AddcustomerComponent },
  { path: 'customerpage/addcustomer', component: RegisterCustomerComponent },
  { path: 'welcome/showlist', component: ShowlistComponent },
  { path: 'welcome/showlist/editcustomer/:id', component: EditcustomerComponent },
  { path: 'customerpage', component: CustomerHomePageComponent },
  { path: 'customerpage/loginCustomer', component: LoginCustomerComponent },
  { path: 'customerpage/loginCustomer/showcustomer', component: ShowCustomerComponent },
  { path: 'customerpage/loginCustomer/showcustomer/editcustomer/:id', component: EditcustomerloginComponent },
  { path: 'customerpage/loginCustomer/showcustomer/registerHomePage', component: CustomerHomePageRegisterComponent },
  { path: '', redirectTo: 'customerpage/loginCustomer', pathMatch: 'full' },
  { path: 'customerpage/addcustomer/registerHomePage/shoppingCart', component: ShoppingCartComponent },
  { path: 'customerpage/loginCustomer/showcustomer/registerHomePage/shoppingCart', component: ShoppingCartComponent },
  { path: 'customerpage/loginCustomer/showcustomer/registerHomePage/reviewpage', component: WriteReviewComponent },
  { path: 'customerpage/addcustomer/registerHomePage/shoppingCart/checkOut', component: CheckOutPageComponent },
  { path: 'customerpage/loginCustomer/showcustomer/registerHomePage/shoppingCart/checkOut', component: CheckOutPageComponent },
  { path: 'customerpage/loginCustomer/showcustomer/registerHomePage/myOrders/View', component: ViewOrderComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
