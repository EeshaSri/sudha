import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { Customerbean } from 'src/app/bean/customerbean';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})
export class AddcustomerComponent implements OnInit {
  customerData:Customerbean={"id":0,"email":"","fullName":"","phoneNumber":"","password": "","address":"","city":"","state":"","country":"", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CategoryService,private router:Router) { }

  ngOnInit() {
  }
  add(){
    console.log(this.customerData.fullName);
    this.customerService.addCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['welcome/showlist']);});
  }


}
