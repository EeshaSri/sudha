import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { User } from 'src/app/bean/user.interface';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrls: ['./edituser.component.css']
})
export class EdituserComponent implements OnInit {

  userData: User = { "id": 0, "email": '', "fullname": '', "password": '' };
  constructor(private userService: CategoryService,
    private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.userService.getUser(params['id'])
        .subscribe((result) => { this.userData = result; })
    })

  }

  edit() {
    console.log(this.userData.fullname);
    this.userService.editUser(this.userData).subscribe(data => { this.router.navigate(['welcome/userList']) });
  }

}
