import { Component, OnInit } from '@angular/core';
import { Customerbean } from 'src/app/bean/customerbean';
import { CategoryService } from 'src/app/service/category.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-show-customer',
  templateUrl: './show-customer.component.html',
  styleUrls: ['./show-customer.component.css']
})
export class ShowCustomerComponent implements OnInit {

  customerData:Customerbean={"id":0,"email":"","fullName":"","phoneNumber":"","password": "","address":"","city":"","state":"","country":"", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CategoryService,private router:Router,private route:ActivatedRoute) {
    this.customerData=this.customerService.showCustomer();
    console.log(this.customerData);
   }
  
  ngOnInit() {
    
    }

}
