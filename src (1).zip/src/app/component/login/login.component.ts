import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { LoginData } from 'src/app/bean/login-data';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
status:boolean;
login:LoginData={"email":'',"password":''};
login1:LoginData;
message:string;
  constructor(private service:CategoryService,private router:Router) { }

  ngOnInit() {
  }
logindata()
{
  this.service.validlogin(this.login).subscribe((data)=>{this.login1=data})
if(this.login1!=null)
{
  if(this.login1.password==this.login.password)
  
  this.router.navigate(['welcome']);

else

  this.message="Invalid Password";

}
}
}
