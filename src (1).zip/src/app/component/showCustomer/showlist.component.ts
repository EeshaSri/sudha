import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { Customerbean } from 'src/app/bean/customerbean';

@Component({
  selector: 'app-showlist',
  templateUrl: './showlist.component.html',
  styleUrls: ['./showlist.component.css']
})
export class ShowlistComponent implements OnInit {
  customers:Customerbean[];
  constructor(private customerService:CategoryService) { }

  ngOnInit() {
    this.customerService.getAllCustomers().subscribe(
      (data:Customerbean[])=>{this.customers=data});
     console.log("all" +this.customers)
  }
  delete(id:number){
    if(window.confirm("Are you sure you want to delete the user with id "+id))
    {
    this.customerService.deleteCustomers(id).subscribe(
      (data)=>{this.customers=data}
  );
    }
  }

}
