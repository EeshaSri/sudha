import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { Book } from 'src/app/bean/book';
import { Review } from 'src/app/bean/review';
import { Customerbean } from 'src/app/bean/customerbean';
import { Router } from '@angular/router';

@Component({
  selector: 'app-write-review',
  templateUrl: './write-review.component.html',
  styleUrls: ['./write-review.component.css']
})
export class WriteReviewComponent implements OnInit {
book:Book;
cust:Customerbean;
review:Review={"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''};
  constructor(private service:CategoryService,private router:Router) { }

  ngOnInit() {
 this.book= this.service.getBookForReview();
 console.log(this.book);
this.cust=this.service.getLoginCustomer();
this.review.customer=this.cust.fullName;
this.review.book=this.book.title;
  }
  onItemChange(event)
  {
this.review.rating=event.target.value;

console.log(this.review.rating);
  }
  writereview()
  {
    this.service.addReview(this.review).subscribe();
    this.router.navigate(['customerpage/loginCustomer/showcustomer/registerHomePage']);
    alert("review submitted successfully");
  }
 
}
