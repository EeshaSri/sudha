import { Component, OnInit } from '@angular/core';


import { CategoryService } from 'src/app/service/category.service';
import { Book } from 'src/app/bean/book';

@Component({
  selector: 'app-show-book',
  templateUrl: './show-book.component.html',
  styleUrls: ['./show-book.component.css']
})
export class ShowBookComponent implements OnInit {
books:Book[];
  constructor(private service:CategoryService) { }

  ngOnInit() {
    this.service.getBooks().subscribe((data=>{this.books=data}));
  }
delete(id:number)
{
  if(window.confirm('are you sure to delete this id'+' '+id))
  {
 this.service.delete(id).subscribe();
 this.service.getBooks().subscribe((data=>{this.books=data}));
  }
}
}
