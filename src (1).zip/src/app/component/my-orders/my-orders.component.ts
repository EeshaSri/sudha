import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { Customerbean } from 'src/app/bean/customerbean';
import { Order } from 'src/app/bean/order';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.css']
})
export class MyOrdersComponent implements OnInit {
customer:Customerbean;
order:Order[];
  constructor(private service:CategoryService, private router :Router) { }

  ngOnInit() {
this.customer=this.service.getLoginCustomer();
this.service.getOrderbyName(this.customer.fullName).subscribe((data)=>{this.order=data});
console.log(this.order)
  }
details(order:Order){
this.service.setOrder(order);
this.router.navigate(['customerpage/loginCustomer/showcustomer/registerHomePage/myOrders/View'])
}

}
