import { Component, OnInit } from '@angular/core';
import { DisplayBook } from 'src/app/bean/display-book';
import { CategoryService } from 'src/app/service/category.service';
import { Book } from 'src/app/bean/book';

@Component({
  selector: 'app-customer-home-page',
  templateUrl: './customer-home-page.component.html',
  styleUrls: ['./customer-home-page.component.css']
})
export class CustomerHomePageComponent implements OnInit {
  BookData:DisplayBook={"category":'',"title":'',"author":'',"description":'',"isbn":'',"price":0,"image":''};
  books:Book[];
  boo:Book;
  constructor(private service:CategoryService) { }

  ngOnInit() {
  }
  search()
  {
  this.service.searchBook(this.BookData.category).subscribe((data)=>{this.books=data;console.log(this.books); this.service.setBookData(this.boo);});
  
 
  }
}
