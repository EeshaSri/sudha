import { Component, OnInit } from '@angular/core';
import { Customerbean } from 'src/app/bean/customerbean';
import { CategoryService } from 'src/app/service/category.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-editcustomerlogin',
  templateUrl: './editcustomerlogin.component.html',
  styleUrls: ['./editcustomerlogin.component.css']
})
export class EditcustomerloginComponent implements OnInit {

  customerData:Customerbean={"id":0,"email":" ","fullName":" ","phoneNumber":" ","password": " ","address":" ","city":" ","state":" ","country":" ", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CategoryService,private router:Router,private route:ActivatedRoute) { }
  
  ngOnInit() {
    this.route.params.subscribe((params)=>{this.customerService.getCustomer(params['id']).subscribe(
      (result)=>{this.customerData=result;})})
      console.log(this.customerData); 
    }
      edit(){
        console.log(this.customerData.id);
        this.customerService.editcustomer(this.customerData).subscribe((data)=>{this.router.navigate(['/customerpage/loginCustomer/showcustomer'])});
        this.customerService.loginData(this.customerData);
        alert('updated successfully');
        
       }  
      }
