import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditcustomerloginComponent } from './editcustomerlogin.component';

describe('EditcustomerloginComponent', () => {
  let component: EditcustomerloginComponent;
  let fixture: ComponentFixture<EditcustomerloginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditcustomerloginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditcustomerloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
