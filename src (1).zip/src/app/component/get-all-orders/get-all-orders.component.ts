import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { Order } from 'src/app/bean/order';
import { CategoryService } from 'src/app/service/category.service';


@Component({
  selector: 'app-get-all-orders',
  templateUrl: './get-all-orders.component.html',
  styleUrls: ['./get-all-orders.component.css']
})
export class GetAllOrdersComponent implements OnInit {
orders: Order[];

  constructor(private orderService:CategoryService,private route:Router) { }

  ngOnInit() {
    this.orderService.getAllOrders().subscribe((data:Order[])=>
    this.orders=data);
  
  }

  deleteOrder(orderedId:number){
    alert: if(window.confirm("Are you sure you want to delete "+orderedId)){
    this.orderService.deleteOrder(orderedId).subscribe((data)=>{this.orders=data});
    }

  }

}
