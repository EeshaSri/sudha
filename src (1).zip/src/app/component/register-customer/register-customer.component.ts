import { Component, OnInit } from '@angular/core';
import { Customerbean } from 'src/app/bean/customerbean';
import { CategoryService } from 'src/app/service/category.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.css']
})
export class RegisterCustomerComponent implements OnInit {

  customerData:Customerbean={"id":0,"email":"","fullName":"","phoneNumber":"","password": "","address":"","city":"","state":"","country":"", "registeredDate":new Date('yyyy-mmm-dd')}
  constructor(private customerService:CategoryService,private router:Router) { }

  ngOnInit() {
  }
  add(){
    console.log(this.customerData.fullName);
    this.customerService.addCustomer(this.customerData).subscribe(
      (data)=>{this.router.navigate(['customerpage/loginCustomer']);});
      alert('you are succesfully registered to continue shopping login again');
  }


}
