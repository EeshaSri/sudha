import { Component, OnInit } from '@angular/core';
import { AddCateggory } from 'src/app/bean/add-categgory';
import { CategoryService } from 'src/app/service/category.service';
import { AddCategory } from 'src/app/bean/add-category';
import { Category } from 'src/app/bean/category';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-category',
  templateUrl: './create-category.component.html',
  styleUrls: ['./create-category.component.css']
})
export class CreateCategoryComponent implements OnInit {
category:Category={"id":0,"categoryName":''};
  constructor(private service:CategoryService,private router: Router) { }

  ngOnInit() {
  }
add(){
this.service.addCategory(this.category).subscribe((data)=>
{this.router.navigate(['welcome/category']); });

alert('added successfully');
this.router.navigate(['welcome/category']); 
}
}
