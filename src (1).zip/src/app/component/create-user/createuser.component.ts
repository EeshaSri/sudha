import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { User } from 'src/app/bean/user.interface';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.css']
})
export class CreateuserComponent implements OnInit {

  userData:User={"id":0,"email":'',"fullname":'',"password":''};
  constructor(private userService:CategoryService,
    private router:Router) { }

  ngOnInit() {
  }
createUser(){
  this.userService.createUser(this.userData).subscribe(data=>{ if(data!=null)this.router.navigate(['welcome/userList']);
else
alert('User already exists ')});
}

}
