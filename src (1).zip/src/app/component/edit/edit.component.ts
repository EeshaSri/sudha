import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { Review } from 'src/app/bean/review';
import { CategoryService } from 'src/app/service/category.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
review:Review[];
  reviewData:Review={"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''}
  constructor(private reviewService:CategoryService, 
    private router:Router,private route:ActivatedRoute){ }

  ngOnInit() {
    this.route.params.subscribe(
      (params)=>{this.reviewService.getReview(params['id'])
    .subscribe((result)=>{this.reviewData=result;})}
    );
  }
  
  edit(){
    console.log(this.reviewData.id);
    this.reviewService.editReview(this.reviewData).subscribe(
);
this.router.navigate(['/welcome/review']);}
    
    }
