import { Component, OnInit } from '@angular/core';
import { DisplayBook } from 'src/app/bean/display-book';
import { CategoryService } from 'src/app/service/category.service';
import { Book } from 'src/app/bean/book';
import { ShopCart } from 'src/app/bean/shop-cart';
import { Customerbean } from 'src/app/bean/customerbean';

@Component({
  selector: 'app-customer-home-page-register',
  templateUrl: './customer-home-page-register.component.html',
  styleUrls: ['./customer-home-page-register.component.css']
})
export class CustomerHomePageRegisterComponent implements OnInit {
  BookData:DisplayBook={"category":'',"title":'',"author":'',"description":'',"isbn":'',"price":0,"image":''};
 books:Book[];
 quantity:number=0;
 cust:Customerbean;
 c:ShopCart={"price":0,"image":'',"title":'',"quantity":0,"subtotal":0};
  constructor(private service:CategoryService) { }

  ngOnInit() {
    this.cust=this.service.getLoginCustomer();
  }
search()
{
this.service.searchBook(this.BookData.category).subscribe((data)=>{this.books=data;
  
  console.log("all"+this.books);});
  

}
addtoCart(title:string,image:string,price:number)
{
  console.log(this.quantity);
  this.c.title=title
  this.c.image=image;
  this.c.price=price;
  this.c.quantity=this.quantity;
  console.log(title);
  this.service.addCart(this.c);
  alert('Item added successfully to cart');

}
review(b:Book)
{
  this.service.setReview(b);
}
}
