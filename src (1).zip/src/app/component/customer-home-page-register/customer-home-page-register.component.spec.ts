import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerHomePageRegisterComponent } from './customer-home-page-register.component';

describe('CustomerHomePageRegisterComponent', () => {
  let component: CustomerHomePageRegisterComponent;
  let fixture: ComponentFixture<CustomerHomePageRegisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerHomePageRegisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerHomePageRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
