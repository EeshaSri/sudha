import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { Router } from '@angular/router';
import { LoginData } from 'src/app/bean/login-data';
import { Customerbean } from 'src/app/bean/customerbean';

@Component({
  selector: 'app-login-customer',
  templateUrl: './login-customer.component.html',
  styleUrls: ['./login-customer.component.css']
})
export class LoginCustomerComponent implements OnInit {
  login:LoginData={"email":'',"password":''};
  login1:Customerbean;
  message:string;
  
  constructor(private service:CategoryService,private router:Router) { }

  ngOnInit() {
  }
  logindata()
  {

    this.service.validCustomer(this.login).subscribe((data)=>{this.login1=data})
    console.log(this.login1);
    this.service.loginData(this.login1);
    if(this.login1!=null){
  if(this.login1!=null)
  {
    if(this.login1.password==this.login.password)
    
    this.router.navigate(['customerpage/loginCustomer/showcustomer']);
  
  else
  
    this.message="Invalid credentials";
  
  }

}
  
}
}
