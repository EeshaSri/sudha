import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { Book } from 'src/app/bean/book';
import { Order } from 'src/app/bean/order';


@Component({
  selector: 'app-edit-order',
  templateUrl: './edit-order.component.html',
  styleUrls: ['./edit-order.component.css']
})
export class EditOrderComponent implements OnInit {
orderData:Order={"orderedId":0,"name":'',"quantity":0,"amount":0,"method":'',"status":'',"ordereddate":new Date('yyyy-mmm-dd')};
books:Book[];
  constructor(private orderService:CategoryService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params)=>
    {this.orderService.getOrder(params['orderedId']).subscribe((result)=>{this.orderData=result})});
    this.orderService.getBooks().subscribe((data)=>
    {this.books=data});
   
  }
 editCustomer(orderedId:number){
    console.log(this.orderData);
    this.orderService.editCustomer(this.orderData).subscribe();
    this.router.navigate(['/welcome/getAllOrders']);
  
  }
  remove(title:string){
    alert: if(window.confirm("Are you sure you want to delete "+title)){
    this.orderService.remove(title).subscribe((data)=>{this.books=data});
    }
  
    
    }

    
      
  
}