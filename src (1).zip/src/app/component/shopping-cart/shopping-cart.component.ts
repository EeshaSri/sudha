import { Component, OnInit } from '@angular/core';
import { Book } from 'src/app/bean/book';
import { CategoryService } from 'src/app/service/category.service';
import { ShopCart } from 'src/app/bean/shop-cart';
import { Order } from 'src/app/bean/order';
import { Order1 } from 'src/app/bean/order1';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
books:Book[];

sum:number=0;
quatity:number;
car:ShopCart[];
cart:ShopCart={"price":0,"image":'',"title":'',"quantity":0,"subtotal":0};
order:Order={"orderedId":0,"name":'',"quantity":0,"amount":0,"method":'',"status":'',"ordereddate":new Date('yyyy-mmm-dd')};
subt:number=0;
ca:number[]=[];

  constructor(private service:CategoryService) { }

  ngOnInit() {
this.car=this.service.getCart();
this.quatity=0;
console.log(this.cart);
this.car.forEach(i => {
  this.sum=this.sum+(i.price*i.quantity);
  this.order.amount=this.sum;
  });
this.car.forEach(i => {
  this.quatity=this.quatity+(i.quantity*1);
  this.order.quantity=this.quatity;
});
console.log(this.order,this.car);
this.service.checkOut(this.order,this.car);
  }

deleteCart(i:number,quant:number,p:number)
{
this.car.splice(i,1);
this.quatity=this.quatity-quant;
this.sum=this.sum-(p*quant);
}

    



  
  
}
