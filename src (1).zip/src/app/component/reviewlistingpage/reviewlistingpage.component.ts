import { Component, OnInit } from '@angular/core';


import { Review } from 'src/app/bean/review';
import { CategoryService } from 'src/app/service/category.service';

@Component({
  selector: 'app-reviewlistingpage',
  templateUrl: './reviewlistingpage.component.html',
  styleUrls: ['./reviewlistingpage.component.css']
})
export class ReviewlistingpageComponent implements OnInit {
  reviews:Review[];
  reviewData:Review={"id":0,"book":'',"rating":0,"headline":'',"customer":'',"reviewOn":''}
  constructor(private reviewService:CategoryService) { }
  
  ngOnInit() {
    this.reviewService.getAllReviews().subscribe((data)=>{this.reviews=data;});
    
   }
   deleteReview(review:Review){
    alert: if(window.confirm("Are you sure you want to delete the review with id "+review.id)){
    this.reviewService.deleteReview(review).subscribe((data)=>{this.reviews=this.reviews.filter(c=>c!==review)});
    }
 }
}