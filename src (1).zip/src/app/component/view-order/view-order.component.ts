import { Component, OnInit } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { Customerbean } from 'src/app/bean/customerbean';
import { Order } from 'src/app/bean/order';
import { ShopCart } from 'src/app/bean/shop-cart';

@Component({
  selector: 'app-view-order',
  templateUrl: './view-order.component.html',
  styleUrls: ['./view-order.component.css']
})
export class ViewOrderComponent implements OnInit {
customer:Customerbean;
checkOutOrder:Order={"orderedId":0,"name":'',"quantity":0,"amount":0,"method":'',"status":'',"ordereddate":new Date('yyyy-mmm-dd')};
carts:ShopCart[];
order:Order;
quantity1:number;
sum:number=0;
  constructor(private service:CategoryService) { }

  ngOnInit() {
this.order=this.service.getPlacedOrder();
this.customer=this.service.getLoginCustomer();
this.checkOutOrder=this.service.getCheckOutOrder();
this.carts=this.service.getCart();
this.quantity1=0;
console.log(this.carts)
if((this.order.quantity==this.checkOutOrder.quantity)&&(this.checkOutOrder.amount==this.order.amount)){
this.carts.forEach(i => {

  this.sum=this.sum+(i.price*i.quantity);
  this.order.amount=this.sum;
}
  
  
);}
if((this.order.quantity==this.checkOutOrder.quantity)&&(this.checkOutOrder.amount==this.order.amount)){
  this.carts.forEach(i => {
  
    this.quantity1=this.quantity1+(i.quantity*1);
    this.order.quantity=this.quantity1;}
  
    
    
  )};


  }
  }
