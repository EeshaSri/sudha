import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { Category } from 'src/app/bean/category';

@Component({
  selector: 'app-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.css']
})
export class EditCategoryComponent implements OnInit {
  category: Category = { "id": 0, "categoryName": ''};
  constructor(private router: Router, private service: CategoryService, private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe((params) => { this.service.getCategory(params['id']).subscribe(result => { this.category = result; }) });
    console.log(this.category.categoryName);
  }
  edit() {
    this.service.updateCategory(this.category).subscribe((data)=>{this.router.navigate(['welcome/category']); });
    this.router.navigate(['welcome/category']); 
  }
}
