import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';
import { CategoryService } from 'src/app/service/category.service';
import { Customerbean } from 'src/app/bean/customerbean';
import { Order } from 'src/app/bean/order';

@Component({
  selector: 'app-add-order',
  templateUrl: './add-order.component.html',
  styleUrls: ['./add-order.component.css']
})
export class AddOrderComponent implements OnInit {
order:Order={"orderedId":0,"name":'',"amount":0,"quantity":0,"method":'',"status":'',"ordereddate":new Date('yyyy-mmm-dd')}
customer:Customerbean;
  constructor(private orderservice:CategoryService, private router:Router) { }
  ngOnInit() {
  }
addOrder(order:Order){

  this.orderservice.addOrder(this.order).subscribe((data)=>{this.router.navigate(['getAllOrders'])});
  alert("added");
 

}

}
