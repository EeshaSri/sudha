import { Component, OnInit } from '@angular/core';
import { Order } from 'src/app/bean/order';
import { ShopCart } from 'src/app/bean/shop-cart';
import { CategoryService } from 'src/app/service/category.service';
import { Customerbean } from 'src/app/bean/customerbean';
import { Order1 } from 'src/app/bean/order1';
import { Router } from '@angular/router';

@Component({
  selector: 'app-check-out-page',
  templateUrl: './check-out-page.component.html',
  styleUrls: ['./check-out-page.component.css']
})
export class CheckOutPageComponent implements OnInit {
order:Order={"orderedId":0,"name":'',"quantity":0,"amount":0,"method":'',"status":'',"ordereddate":new Date('yyyy-mmm-dd')};
cart:ShopCart[];
cust:Customerbean={"id":0,"email":"","fullName":"","phoneNumber":"","password": "","address":"","city":"","state":"","country":"", "registeredDate":new Date('yyyy-mmm-dd')};
  constructor(private service:CategoryService, private router:Router) { }

  ngOnInit() {
   
this.order=this.service.getCheckOutOrder();
this.cart=this.service.getCheckOutCart();
this.cust=this.service.getRegisterCustomer();
this.cust=this.service.getLoginCustomer();
console.log(this.order,this.cart,this.cust);
this.order.status="processing";
this.order.method="cash on delivery";
this.order.name=this.cust.fullName;

  }
  placeOrder(){
    console.log("hii")
    this.service.addOrder(this.order).subscribe();
    this.router.navigate(['customerpage/loginCustomer/showcustomer/registerHomePage']);
  }

}
