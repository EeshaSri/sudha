import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { DisplayBook } from 'src/app/bean/display-book';
import { CategoryService } from 'src/app/service/category.service';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  BookData:DisplayBook={"category":'',"title":'',"author":'',"description":'',"isbn":'',"price":0,"image":''};
  constructor(private service:CategoryService,private router:Router,private route:ActivatedRoute) { }

  ngOnInit() {

    this.route.params.subscribe((params)=>{this.service.getById(params['id']).subscribe((result)=>{this.BookData=result;})})
    console.log(this.BookData);
  }
update()
{
  this.service.update(this.BookData).subscribe((data)=>{this.router.navigate(['welcome/booklist'])});
  alert('updated succesfully');
}
}
