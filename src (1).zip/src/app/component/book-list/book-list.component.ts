import { Component, OnInit } from '@angular/core';

import { Router } from '@angular/router';

import { CategoryService } from 'src/app/service/category.service';
import { DisplayBook } from 'src/app/bean/display-book';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Category } from 'src/app/bean/category';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {
BookData:DisplayBook={"category":'',"title":'',"author":'',"description":'',"isbn":'',"price":0,"image":''};
category:Category[];
  constructor(private service:CategoryService,private router:Router) {
    this.service.getAllCategories().subscribe(data=>{this.category=data});
   }

  ngOnInit() {
  }
add()
{
this.service.add(this.BookData).subscribe((data)=>{this.router.navigate(['welcome/booklist']);});
alert('added succesfully');


}
}
