import { Component, OnInit } from '@angular/core';
import { Order } from '../bean/order';
import { Customer } from '../bean/customer';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-add-order',
  templateUrl: './add-order.component.html',
  styleUrls: ['./add-order.component.css']
})
export class AddOrderComponent implements OnInit {
order:Order;
customer:Customer;
  constructor(private orderservice:OrderService) { }
  ngOnInit() {
  }
addOrder(name:string,quantity:number,amount:number,method:string,status:string){
this.order=new Order(name,quantity,amount,method,status);
this.orderservice.addOrder(this.order).subscribe((date)=>{console.log(this.order)})
}
}
