import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddOrderComponent } from './add-order/add-order.component';
import { GetAllOrdersComponent } from './get-all-orders/get-all-orders.component';
import{ FormsModule,ReactiveFormsModule} from '@angular/forms';
import{ HttpClientModule} from '@angular/common/http';
import { OrderService } from './order.service';
@NgModule({
  declarations: [
    AppComponent,
    AddOrderComponent,
    GetAllOrdersComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [OrderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
