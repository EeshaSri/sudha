import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { Order } from '../bean/order';

@Component({
  selector: 'app-get-all-orders',
  templateUrl: './get-all-orders.component.html',
  styleUrls: ['./get-all-orders.component.css']
})
export class GetAllOrdersComponent implements OnInit {
orders: Order[];
  constructor(private orderservice:OrderService) { }

  ngOnInit() {
    this.orderservice.getAllOrders().subscribe((data:Order[])=>{this.orders=data;console.log("all"+this.orders)})
  }

}
