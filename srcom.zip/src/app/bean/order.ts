export class Order {
    index: number
    orderId: number;
    name: string;
    quantity: number;
    amount: number;
    method: string;
    status: string;
    date: Date;

constructor(name:string,quantity:number,amount:number,method:string,status:string){
this.name=name;
this.quantity=quantity;
this.amount=amount;
this.method=method;
this.status=status;


}
}
