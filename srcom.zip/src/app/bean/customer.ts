export class Customer {
    name: string;
    phone: number;
    address: string;
    city :string;
    pincode: number;
    country: string

}
