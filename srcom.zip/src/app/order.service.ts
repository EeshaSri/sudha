import { Injectable } from '@angular/core';
import { Order } from './bean/order';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


const httpOptions={headers: new HttpHeaders({'Content-Type':'application/json'})};

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private userUrl='http://localhost:7000/';
  order:Order

  constructor(private http:HttpClient) { }
  public getAllOrders(){
    return this.http.get<Order[]>(this.userUrl);

  }
  public addOrder(order:Order): Observable <Order>{
return this.http.post<Order>(this.userUrl, order);
  }
}
