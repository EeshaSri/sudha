package com.cg.order.exception;

public class OrderException extends Exception{
public OrderException() {
	super();
}
	public OrderException(String message) {
		super(message);
	}

}
