package com.cg.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.order.bean.Order;
import com.cg.order.exception.OrderException;
import com.cg.order.service.OrderService;

public class OrderController {

@RequestMapping("/api")
@RestController
public class CourseController {
	@Autowired
 public OrderService orderservice;
	

	@GetMapping("/coursedetails")
	public List<Order>getAllCourseDetails() throws OrderException{
		return orderservice.getAllOrders();
	}
	@PostMapping("/coursedetails")
	public List<Order>addCourseDetails(@RequestBody Order order) throws OrderException{
		return orderservice.addOrder(order);
	}
	
}


}
