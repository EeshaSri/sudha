package com.cg.order.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@SequenceGenerator(name="seq2", initialValue=100, allocationSize=1)
@SequenceGenerator(name="seq1", initialValue=1, allocationSize=1)
@Table(name="BookOrder")
public class Order {
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq1")
private int index;
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="seq2")
private int orderedId;
private Customer customer;
private int quantity;
private int amount;
private String method;

}
