package com.cg.order.service;

import java.util.List;

import com.cg.order.bean.Customer;
import com.cg.order.bean.Order;
import com.cg.order.exception.OrderException;

public interface OrderService {
	List<Order>getAllOrders()throws OrderException;
	List<Order>getDetails()throws OrderException;
	List<Order>deletecustomer()throws OrderException;
    List<Order>updatecustomer()throws OrderException;
    List<Order>addOrder(Order order) throws OrderException;
}
