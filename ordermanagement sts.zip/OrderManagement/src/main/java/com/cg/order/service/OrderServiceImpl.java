package com.cg.order.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.order.bean.Order;
import com.cg.order.dao.OrderRepository;
import com.cg.order.exception.OrderException;


@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderdao;

	@Override
	public List<Order> getAllOrders() throws OrderException {
	try {
		return orderdao.findAll();
	} catch (Exception e) {
		
	throw new OrderException(e.getMessage());
	}
		
	}

	@Override
	public List<Order> getDetails() throws OrderException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> deletecustomer() throws OrderException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> updatecustomer() throws OrderException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> addOrder(Order order) throws OrderException {
		orderdao.save(order);
		return getAllOrders();
	}
}
