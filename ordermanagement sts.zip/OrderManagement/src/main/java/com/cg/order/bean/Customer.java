package com.cg.order.bean;

public class Customer {
private String name;
private String phone;
private String address;
private String city;
private int pinCode;
private String country;
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
public Customer(String name, String phone, String address, String city, int pinCode, String country) {
	super();
	this.name = name;
	this.phone = phone;
	this.address = address;
	this.city = city;
	this.pinCode = pinCode;
	this.country = country;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getPinCode() {
	return pinCode;
}
public void setPinCode(int pinCode) {
	this.pinCode = pinCode;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}


}
