package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Bank")
public class AccountDetails {
	@Id
	@SequenceGenerator(name = "acc", sequenceName = "acc_seq",initialValue=1001,allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "acc")
	
	private int accountNumber;
	private String title;
	private String email;
	private double phone;
	private double amount;
	public AccountDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AccountDetails(int accountNumber, String title, String email, double phone, double amount) {
		super();
		this.accountNumber = accountNumber;
		this.title = title;
		this.email = email;
		this.phone = phone;
		this.amount = amount;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getPhone() {
		return phone;
	}
	public void setPhone(double phone) {
		this.phone = phone;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "AccountDetails [accountNumber=" + accountNumber + ", title=" + title + ", email=" + email + ", phone="
				+ phone + ", amount=" + amount + "]";
	}
	
}
